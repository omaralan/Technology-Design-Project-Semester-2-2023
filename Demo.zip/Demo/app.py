from flask import Flask, request, render_template, jsonify
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.neural_network import MLPClassifier
import re
import nltk
from nltk.stem import WordNetLemmatizer
import torch
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

app = Flask(__name__)

# Load trained model for paragraph classification
model = pickle.load(open("MLP.pkl", "rb"))

# Load the summarization model and tokenizer
summarizer = AutoModelForSeq2SeqLM.from_pretrained("humarin/chatgpt_paraphraser_on_T5_base")
summarizer_tokenizer = AutoTokenizer.from_pretrained("humarin/chatgpt_paraphraser_on_T5_base")

# Predefine a list of problematic keywords
keywords = ["shared", "commercial", "advertiser", "transfer personal information",
           "third parties", "shared", "share", "affliate", "disclose", "third party", "permanently stored", "card information",
           "payment information", "financial", "group company", "cookies", "beacon", "affiliates", "advertising partners",
           "partner","card number", "thirdparty", "overseas", "transfer information", "personal information", "transfer",
           "partners","share","disclosure", "credit card","tracking", "other countries","third-party","prior consent",
           "affiliated companies", "transferred", "accessed", "marketing", "subsidiaries","parent companies", "parent company", "sharing",
           "share your information", "share your personal information", "outside the country", "without giving notice", "sell",
           "business partners", "payment processors", "other organisations", "companies", "payment", "payment providers", "their privacy policies",
           "related bodies corporate", "cvv", "payment service providers", "service providers"]

# Load the TF-IDF vectorizer that was saved during model training
with open("tfidf_vectorizer.pkl", "rb") as vectorizer_file:
    tfidf_vectorizer = pickle.load(vectorizer_file)

# Define a function to clean the input text
def preprocess_text(text):
    # Remove user mentions, URLs, hashtags, emojis, punctuation, and double spaces
    cleaned_text = remove_unwanted(text)
    
    # Tokenize the cleaned text
    tokens = nltk.word_tokenize(cleaned_text)
    
    # Remove stopwords
    cleaned_tokens = remove_words(tokens)
    
    # Lemmatize the cleaned tokens
    lemmatized_tokens = lemmatize(cleaned_tokens)
    
    # Join the lemmatized tokens into a cleaned text string
    cleaned_text = ' '.join(lemmatized_tokens)
    
    return cleaned_text

def remove_emoji(string):
    emoji_pattern = re.compile("["
                           u"\U0001F600-\U0001F64F"  
                           u"\U0001F300-\U0001F5FF"  
                           u"\U0001F680-\U0001F6FF"  
                           u"\U0001F1E0-\U0001F1FF"  
                           u"\U00002702-\U000027B0"
                           u"\U000024C2-\U0001F251"
                           "]+", flags=re.UNICODE)
    return emoji_pattern.sub(r' ', string)

def remove_unwanted(document):
    # remove user mentions
    document = re.sub("@[A-Za-z0-9_]+", " ", document)
    # remove URLS
    document = re.sub(r'http\S+', ' ', document)
    # remove hashtags
    document = re.sub("#[A-Za-z0-9_]+", "", document)
    # remove emoji's
    document = remove_emoji(document)
    # remove punctuation
    document = re.sub("[^0-9A-Za-z ]", " ", document)
    # remove double spaces
    document = document.replace('  ', " ")
    return document.strip()

def remove_words(tokens):
    stopwords = nltk.corpus.stopwords.words('english')
    stopwords = [remove_unwanted(word) for word in stopwords]
    cleaned_tokens = [token for token in tokens if token not in stopwords]
    return cleaned_tokens

lemma = WordNetLemmatizer()

def lemmatize(tokens):
    lemmatized_tokens = [lemma.lemmatize(token, pos='v') for token in tokens]
    return lemmatized_tokens

# Define a function to generate an explanation using the summarization model
def generate_explanation(
    input_text,
    num_beams=5,
    num_beam_groups=5,
    repetition_penalty=5.0,
    diversity_penalty=3.0,
    no_repeat_ngram_size=2,
    max_length=256
):
    input_ids = summarizer_tokenizer(
        f'paraphrase: {input_text}',
        return_tensors="pt", padding="longest",
        max_length=max_length,
        truncation=True,
    ).input_ids

    outputs = summarizer.generate(
        input_ids, repetition_penalty=repetition_penalty,
        num_beams=num_beams, num_beam_groups=num_beam_groups,
        max_length=max_length, diversity_penalty=diversity_penalty
    )

    explanation = summarizer_tokenizer.decode(outputs[0], skip_special_tokens=True)

    return explanation

# Define a function to highlight problematic phrases within the text
def highlight_problematic(text, prediction):
    words = text.split()
    highlighted_text = ""
    i = 0
    while i < len(words):
        matched = False
        for phrase in keywords:
            phrase_words = phrase.split()
            if i + len(phrase_words) <= len(words):
                if all(phrase_words[j].lower() in words[i + j].lower() for j in range(len(phrase_words))):
                    if prediction == 'Non-acceptable':
                        highlighted_text += ' '.join([f'<span class="highlight">{word}</span>' for word in words[i:i + len(phrase_words)]]) + ' '
                    else:
                        highlighted_text += ' '.join(words[i:i + len(phrase_words)]) + ' '
                    i += len(phrase_words)
                    matched = True
                    break
        if not matched:
            highlighted_text += words[i] + ' '
            i += 1
    return highlighted_text.strip()

@app.route('/', methods=['GET', 'POST'])
def predict():
    highlighted_text = None
    explanation = None

    if request.method == 'POST':
        try:
            data = request.form['text']
            
            # Preprocess the input text
            text = preprocess_text(data)

            # Vectorize the input text using the fitted TF-IDF vectorizer
            text_tfidf = tfidf_vectorizer.transform([text])

            # Make predictions using the loaded model
            result = model.predict(text_tfidf)

            prediction = result[0]

            # Map 'yes' to 'Acceptable' and 'no' to 'Non-acceptable'
            if prediction == 'yes':
                prediction = 'Acceptable'
            elif prediction == 'no':
                prediction = 'Non-acceptable'

            # Call the highlight_problematic function to update the highlighted_text
            highlighted_text = highlight_problematic(data, prediction)
            
            # Provide explanations for both "Acceptable" and "Non-acceptable" text
            explanation = generate_explanation(data)

            return render_template('index.html', prediction=prediction, highlighted_text=highlighted_text, explanation=explanation)

        except Exception as e:
            return jsonify({'error': str(e)})
    else:
        return render_template('index.html', highlighted_text=highlighted_text, explanation=explanation)

if __name__ == '__main__':
    app.run(debug=True)