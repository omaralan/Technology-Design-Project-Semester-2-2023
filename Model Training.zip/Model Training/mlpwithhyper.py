import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, classification_report
import pickle

# Load the dataset
data = pd.read_csv("AugmentedData.csv")

# Define the features (X) and target (y)
X = data['Cleaned Text']
y = data['Result']

# Create a TF-IDF vectorizer
tfidf_vectorizer = TfidfVectorizer()

# Fit the TF-IDF vectorizer on your data
X_train_tfidf = tfidf_vectorizer.fit_transform(X)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_train_tfidf, y, test_size=0.20, random_state=49)

# Define the best hyperparameters
#best_params = {'hidden_layer_sizes': (200, 100, 50), 'max_iter': 1000}
best_params = {'hidden_layer_sizes': (150, 100, 50), 'max_iter': 300}

# Initialize the MLP classifier with the best parameters
best_mlp_classifier = MLPClassifier(hidden_layer_sizes=best_params['hidden_layer_sizes'], max_iter=best_params['max_iter'], activation='relu', solver='adam', random_state=1)

# Fit the classifier to the training data
best_mlp_classifier.fit(X_train, y_train)

# Make predictions on the test set
y_pred = best_mlp_classifier.predict(X_test)

# Evaluate the model
accuracy = accuracy_score(y_test, y_pred)
classification_rep = classification_report(y_test, y_pred)

print(f"Accuracy: {accuracy}")
print("Classification Report:\n", classification_rep)

# Save the fitted TF-IDF vectorizer and the trained model to files
with open('tfidf_vectorizer.pkl', 'wb') as vectorizer_file:
    pickle.dump(tfidf_vectorizer, vectorizer_file)

with open('MLP.pkl', 'wb') as model_file:
    pickle.dump(best_mlp_classifier, model_file)
